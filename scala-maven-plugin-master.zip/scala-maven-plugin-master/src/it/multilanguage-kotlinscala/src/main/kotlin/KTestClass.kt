open class KTestClass {
}