package p1

class MyClass {
}

//Companion Class
object MyClass {
}