class ScalaClass extends JavaInterface {
	
	override def abstractJavaMethod() : Unit = {
			Console.println("Test")
	}
}