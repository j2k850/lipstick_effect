public class X extends A {
    public int x = a;
}