class Y extends X {
  val y = x
}