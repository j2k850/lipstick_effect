class MyClass {
}

//Companion Class
object MyClass {
}