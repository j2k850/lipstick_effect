package p2

class MyClass {
}

//Companion Class
object MyClass {
}