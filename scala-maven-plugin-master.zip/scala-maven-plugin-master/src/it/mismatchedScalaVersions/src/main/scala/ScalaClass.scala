class ScalaClass {
	
	def abstractJavaMethod() : Unit = {
			Console.println("Test")
	}
}