
object MyClass extends KTestClass {
}