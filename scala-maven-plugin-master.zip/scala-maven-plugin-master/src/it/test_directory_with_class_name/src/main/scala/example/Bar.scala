package example

object Bar extends App {
    println("Hello world")
}
