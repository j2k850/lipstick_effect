new File(basedir, 'target/classes/ScalaClass.class').exists()
