public class HelloJava {
  public void sayHello() {
    System.out.println("Java says:Hello Scala!");
	HelloScala.sayHello();
  }
}