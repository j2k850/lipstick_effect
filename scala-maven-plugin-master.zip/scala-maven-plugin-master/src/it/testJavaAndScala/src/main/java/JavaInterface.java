
public interface JavaInterface {
	public void abstractJavaMethod();
}