package example

object Foo extends App {
    println("Hello world")
}
