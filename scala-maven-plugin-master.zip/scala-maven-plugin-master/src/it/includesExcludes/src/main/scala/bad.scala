import bad.package.name

class bad extends name {}