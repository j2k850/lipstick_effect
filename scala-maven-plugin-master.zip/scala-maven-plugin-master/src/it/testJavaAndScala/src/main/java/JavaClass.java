class JavaClass extends ScalaClass {
	public static void main(String [] args) {
		JavaClass test = new JavaClass();
		test.abstractJavaMethod();
	}
}