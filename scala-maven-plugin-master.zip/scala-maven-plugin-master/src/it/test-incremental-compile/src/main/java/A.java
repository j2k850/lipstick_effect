public class A {
    public int a = 3;
}
